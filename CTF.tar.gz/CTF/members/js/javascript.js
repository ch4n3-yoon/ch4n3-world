$('#search').click(function() {
    var username = $("#username").val().trim();
	if (username == "") return;
	
     var url = "./search.php?search=" + username;
     var params = "search=" + username;
	 $.ajax({
		  type: "POST",
		  url: url,
		  data: params,
		  success: function(data) {
			  $("#result").html(data);
			  $("#result").hide().show('medium');
		  }
	 })
});