<?php

function alertMsg( $msg, $location=1 )
{
	if ($location === 1)
	{
		echo "<script>alert('$msg'); history.back(); </script>";
	}

	else
	{
		echo "<script>alert('$msg'); location.href='$location'; </script>";
	}
}


?>