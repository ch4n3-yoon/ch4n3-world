
var query = location.href.split('#');
 
document.cookies = 'anchor=' + query[1];
 