#!/usr/bin/python
# coding: utf-8

import requests
import sys

if len( sys.argv ) < 2:
    sys.exit(0);


argv = sys.argv[1]

# url = "http://localhost/members/search.php?search=admin' order by 1-- -&encoding=UTF-8"
url = argv
r = requests.get(url)

print r.text
