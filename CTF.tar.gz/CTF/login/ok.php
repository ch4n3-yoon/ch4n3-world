<?php


/* SQLMAP Block */
$userAgent	= $_SERVER['HTTP_USER_AGENT'];
if ( preg_match("/sqlmap/i", $userAgent) )
{
	alertMsg("No hack ~_~");
}


// session start
session_start();

include "../functions.php";
include "../dbconfig.php";


$id         = addslashes($_POST['id']);
$password   = hash('sha256', $_POST['password']);

$query      = "SELECT * FROM `users` WHERE id='{$id}' AND password='{$password}'";
$result     = mysqli_query($conn, $query);
$fetch      = mysqli_fetch_array($result);




if ( isset($fetch['id']) ) 
{

    /* Login success */
    alertMsg("Login success.", "/");
    $_SESSION['id']             = $fetch['id'];
    $_SESSION['firstName']      = $fetch['firstname'];
    $_SESSION['lastName']       = $fetch['lastname'];
    $_SESSION['age']            = $fetch['age'];
} 

else 
{
    /* Login failed */
    alertMsg("Login failed.");
}



?>