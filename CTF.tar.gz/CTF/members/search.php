<?php

/* Set XML */
header("Content-type: application/xml; charset=UTF-8");

include "../functions.php";

/* Get member name */
$search     = $_GET['search'];
$encoding   = $_GET['encoding'];

if (!isset($encoding) || $encoding == "")
{
	$encoding = "UTF-8";
}

/* Prevent Simple SQL Injection */
if (preg_match("/ |\n|\t|information/i", $search))
{
	echo "No Hack ~_~";
	exit(0);
}


/* Create Cursor */
include "../dbconfig.php";

$query      = "SELECT * FROM `users` WHERE `id`='{$search}'";
//echo $query;
$result     = mysqli_query($conn, $query);
$fetch      = mysqli_fetch_array($result);

if (! isset($fetch['id']))
{
    exit(0);
}

?>
<?xml version="1.0" encoding="<?php echo $encoding ?>"?>
<user>  
    <id><?php echo $fetch['id'] ?></id>
    <firstname><?php echo $fetch['firstname'] ?></firstname>
    <lastname><?php echo $fetch['lastname'] ?></lastname>
	<age><?php echo $fetch['age'] ?></age>
</user>

<?php


?>