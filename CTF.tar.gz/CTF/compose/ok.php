<?php

// http://localhost/compose/?to=asdfasdfasdf&importance=1&message=asdfasdf

session_start();

include "../functions.php";

if (!isset($_SESSION['id']))
{
    alertMsg("Login first.", "/");
}


$to         = $_POST['to'];
$subject    = $_POST['subject'];
$importance = $_POST['importance'];
$message    = $_POST['message'];


/* Prevent XSS */
$subject    = htmlspecialchars($subject, ENT_QUOTES, 'UTF-8');
$message    = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

/* Prevent SQLi */
$to         = addslashes($to);

/* MISC */
$importance = ($importance === "1") ? 1 : 0;


/* 
mysql> desc mailbox;
+------------+--------------+------+-----+---------+----------------+
| Field      | Type         | Null | Key | Default | Extra          |
+------------+--------------+------+-----+---------+----------------+
| no         | int(11)      | NO   | PRI | NULL    | auto_increment |
| from       | varchar(30)  | NO   |     | NULL    |                |
| to         | varchar(30)  | NO   |     | NULL    |                |
| subject    | varchar(100) | NO   |     | NULL    |                |
| content    | text         | NO   |     | NULL    |                |
| date       | varchar(19)  | NO   |     | NULL    |                |
| importance | tinyint(1)   | NO   |     | NULL    |                |
| label      | varchar(50)  | NO   |     | NULL    |                |
| trash      | tinyint(1)   | NO   |     | NULL    |                |
| read       | tinyint(1)   | NO   |     | NULL    |                |
+------------+--------------+------+-----+---------+----------------+
10 rows in set (0.02 sec)

*/


/* Insert into DB */

// Create MySQL cursor
include '../dbconfig.php';

$query      = "INSERT INTO `mailbox` (from, to, subject, content, date, importance, label, trash, read) VALUES ";
$query     .= "('{$_SESSION['id']}', '{$to}', '{$subject}', '{$message}', now(), {$importance}, '', 0, 0)";

$query      = "INSERT INTO `mailbox` (`no`, `from`, `to`, `subject`, `content`, `date`, `importance`, `label`, `trash`, `read`) ";
$query     .= "VALUES (NULL, '{$_SESSION['id']}', '{$to}', '{$subject}', '{$message}', NOW(), {$importance}, '', 0, 0)";

$result     = mysqli_query($conn, $query);

// echo $query;

alertMsg("Success to send");


?>
