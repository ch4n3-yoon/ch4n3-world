<!doctype html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>
</head>
<body>

<?php

//error_reporting(~0);
//ini_set('display_errors', 1);

$url = $_GET['url'];
//echo $url . "<br>\n\n\n\n";

$url = escapeshellarg($url);
$xmlstring = shell_exec("./geturl.py {$url}");

$dom = new DOMDocument();
$dom->loadXML($xmlstring, LIBXML_NOENT | LIBXML_DTDLOAD);
$info = simplexml_import_dom($dom);

//echo "\n\n" . gettype($info) . "<br>\n\n";
//print_r($info);

//echo $url . "<br>\n";
//echo $xmlstring;


$xml = simplexml_load_string($xmlstring);

//print_r($xml);



/*
<?xml version="1.0" encoding="UTF-8"?>
<user>
    <id>admin</id>
    <firstname>admin</firstname>
    <lastname>admin</lastname>
    <age>24</age>
</user>
*/

//echo "<br><br>";

//print_r($xml);


/* Set JSON header */
//header('Content-type: application/json');

//echo "<br><br>\n\n";
//
//echo "Your id is " . $info->id . "!\n";
//
//echo "<br><br>";
//echo "User name is {$info->firstname} {$info->lastname}<br>";
//echo "User age is {$info->age}<br>";


//echo '{"id": "'.$info->id.'", "firstname": "'.$info->firstname.'", "lastname": "'.$info->lastname.'", "age": "'.$info->age.'"}';


?>
<h1>User Infomation</h1>
<hr>
id : <?php echo $info->id ?><br>
Full Name : <?php echo $info->firstname ?> <?php echo $info->lastname ?><br>
age : <?php echo $info->age ?>
<br>
<br>
<a href="./index.php">Home</a>
</body>
</html>
