<?php

/*
 * firstName=asdf&lastName=asdf&age=1212312&id=asdfasdfasdfasdfasdf&password=password&password_confirmation=password
 *
*/


/* SQLMAP Block */
$userAgent	= $_SERVER['HTTP_USER_AGENT'];
if ( preg_match("/sqlmap/i", $userAgent) )
{
	alertMsg("No hack ~_~");
}


include "../functions.php";
include "../dbconfig.php";


$datas = array("firstName", "lastName", "age", "id", "password", "password_confirmation");

if ($_POST['password'] !== $_POST['password_confirmation'])
{
	alertMsg("Please check your password.");
}


$firstName  = addslashes($_POST['firstName']);
$lastName   = addslashes($_POST['lastName']);
$age        = (int)$_POST['age'];
$id         = addslashes($_POST['id']);
$password   = hash('sha256', $_POST['password']);       /* length == 64 byte */


/* ID check */

$query      = "SELECT * FROM `users` WHERE id=({'$id'})";
$result     = mysqli_query($conn, $query);
$fetch      = mysqli_fetch_array($result);

if (isset($fetch['id']))
{
	alertMsg("Your id already exists.");
	exit(0);
}



/* Length check */
/* Prevent Column Truncation Attack */

if (strlen($firstName) > 30)
{
	alertMsg("Your first name is too long.");
	exit(0);
}

if (strlen($lastName) > 30)
{
	alertMsg("Your last name is too long.");
	exit(0);
}


if (strlen($id) < 5)
{
	alertMsg("Your id is too short.");
	exit(0);
}



/* insert into DB */
$query      = "INSERT INTO `users` (id, password, firstname, lastname, age) VALUES ('{$id}', '{$password}','{$firstName}', '{$lastName}', {$age})";
$result     = mysqli_query($conn, $query);


/* Check DB */
$query      = "SELECT * FROM `users` WHERE id='{$id}' AND password='{$password}'";
$result     = mysqli_query($conn, $query);
$fetch      = mysqli_fetch_array($result);

if (!isset($fetch['id']))
{
	alertMsg("Join failed.");
}

else 
{
	alertMsg("Join success.", "/login/");
}


?>